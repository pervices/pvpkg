/* -*- c++ -*- */
/*
 * Copyright 2005 Free Software Foundation, Inc.
 *
 * This file is part of GNU Radio
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 */

#ifndef INCLUDED_AUDIO_JACK_IMPL_H
#define INCLUDED_AUDIO_JACK_IMPL_H

#include <cstdio>

#endif /* INCLUDED_AUDIO_JACK_IMPL_H */
